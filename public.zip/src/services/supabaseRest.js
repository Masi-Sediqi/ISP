const SUPABASE_URL = String(import.meta.env.VITE_SUPABASE_URL || "").replace(/\/+$/, "");
const SUPABASE_ANON_KEY = String(import.meta.env.VITE_SUPABASE_ANON_KEY || "");
const TABLE = "app_records";

export const supabaseConfigured = Boolean(SUPABASE_URL && SUPABASE_ANON_KEY);

function headers(extra = {}) {
  return {
    apikey: SUPABASE_ANON_KEY,
    Authorization: `Bearer ${SUPABASE_ANON_KEY}`,
    "Content-Type": "application/json",
    ...extra,
  };
}

async function request(path, options = {}) {
  if (!supabaseConfigured) {
    throw new Error("Supabase is not configured.");
  }

  const method = String(options.method || "GET").toUpperCase();
  const canRetry = method === "GET";
  const maxAttempts = canRetry ? 5 : 1;
  let lastError = null;

  for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), 15000);

    try {
      const response = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, {
        ...options,
        headers: headers(options.headers),
        signal: options.signal || controller.signal,
        cache: method === "GET" ? "no-store" : options.cache,
      });

      if (!response.ok) {
        const detail = await response.text().catch(() => "");
        const error = new Error(
          `Supabase request failed (${response.status}): ${detail || response.statusText}`
        );
        error.status = response.status;
        throw error;
      }

      if (response.status === 204) return null;
      const text = await response.text();
      return text ? JSON.parse(text) : null;
    } catch (error) {
      lastError = error?.name === "AbortError"
        ? new Error("Supabase request timed out.")
        : error;

      const retryableStatus = !lastError?.status || lastError.status >= 500 || lastError.status === 429;
      if (!canRetry || attempt >= maxAttempts || !retryableStatus) {
        throw lastError;
      }

      const backoffMs = Math.min(5000, 500 * (2 ** (attempt - 1))) + Math.floor(Math.random() * 250);
      await new Promise((resolve) =>
        window.setTimeout(resolve, backoffMs)
      );
    } finally {
      window.clearTimeout(timeout);
    }
  }

  throw lastError || new Error("Supabase request failed.");
}

export async function fetchRemoteCollection(collection) {
  // Read collections in pages instead of one potentially huge response.
  // This matters because some records contain base64 images/files.
  const pageSize = 250;
  const records = [];
  let offset = 0;

  while (true) {
    const query = new URLSearchParams({
      select: "record_data",
      collection_name: `eq.${collection}`,
      deleted_at: "is.null",
      order: "updated_at.asc",
      limit: String(pageSize),
      offset: String(offset),
    });

    const rows = await request(`${TABLE}?${query.toString()}`, { method: "GET" });
    const safeRows = Array.isArray(rows) ? rows : [];
    records.push(...safeRows.map((row) => row.record_data).filter(Boolean));

    if (safeRows.length < pageSize) break;
    offset += pageSize;
  }

  return records;
}

export async function pushRemoteChanges({ collection, upserts, deletes, actorId, ownerId, identityFn }) {
  const now = new Date().toISOString();

  if (upserts.length) {
    const rows = upserts.map((record) => ({
      collection_name: collection,
      record_id: identityFn(record),
      record_data: record,
      actor_id: actorId || null,
      owner_id: ownerId || actorId || null,
      updated_at: now,
      deleted_at: null,
    }));

    await request(`${TABLE}?on_conflict=collection_name,record_id`, {
      method: "POST",
      headers: { Prefer: "resolution=merge-duplicates,return=minimal" },
      body: JSON.stringify(rows),
    });
  }

  if (deletes.length) {
    const rows = deletes.map((recordId) => ({
      collection_name: collection,
      record_id: String(recordId),
      record_data: {},
      actor_id: actorId || null,
      owner_id: ownerId || actorId || null,
      updated_at: now,
      deleted_at: now,
    }));

    await request(`${TABLE}?on_conflict=collection_name,record_id`, {
      method: "POST",
      headers: { Prefer: "resolution=merge-duplicates,return=minimal" },
      body: JSON.stringify(rows),
    });
  }
}


const BACKUP_PAGE_SIZE = 1000;
const RESTORE_CHUNK_SIZE = 200;

function chunkRows(rows, size = RESTORE_CHUNK_SIZE) {
  const chunks = [];
  for (let index = 0; index < rows.length; index += size) {
    chunks.push(rows.slice(index, index + size));
  }
  return chunks;
}

export async function fetchAllRemoteRows() {
  const rows = [];
  let offset = 0;

  while (true) {
    const query = new URLSearchParams({
      select: "collection_name,record_id,record_data,actor_id,owner_id,updated_at,deleted_at",
      order: "collection_name.asc,record_id.asc",
      limit: String(BACKUP_PAGE_SIZE),
      offset: String(offset),
    });

    const page = await request(`${TABLE}?${query.toString()}`, { method: "GET" });
    const safePage = Array.isArray(page) ? page : [];
    rows.push(...safePage);

    if (safePage.length < BACKUP_PAGE_SIZE) break;
    offset += BACKUP_PAGE_SIZE;
  }

  return rows;
}

async function upsertRawRows(rows) {
  const validRows = (Array.isArray(rows) ? rows : []).filter(
    (row) => row?.collection_name && row?.record_id
  );

  for (const chunk of chunkRows(validRows)) {
    await request(`${TABLE}?on_conflict=collection_name,record_id`, {
      method: "POST",
      headers: { Prefer: "resolution=merge-duplicates,return=minimal" },
      body: JSON.stringify(chunk),
    });
  }
}

function remoteRowKey(row) {
  return `${String(row?.collection_name || "")}\u0000${String(row?.record_id || "")}`;
}

function stableJson(value) {
  if (Array.isArray(value)) return `[${value.map(stableJson).join(",")}]`;
  if (value && typeof value === "object") {
    return `{${Object.keys(value)
      .sort()
      .map((key) => `${JSON.stringify(key)}:${stableJson(value[key])}`)
      .join(",")}}`;
  }
  return JSON.stringify(value);
}

export async function restoreRemoteSnapshot(snapshotRows = []) {
  if (!supabaseConfigured) {
    throw new Error("Supabase is not configured.");
  }

  const backupRows = (Array.isArray(snapshotRows) ? snapshotRows : []).filter(
    (row) => row?.collection_name && row?.record_id
  );
  const currentRows = await fetchAllRemoteRows();
  const backupKeys = new Set(backupRows.map(remoteRowKey));
  const now = new Date().toISOString();

  const tombstonesForExtraRows = currentRows
    .filter((row) => !backupKeys.has(remoteRowKey(row)) && !row.deleted_at)
    .map((row) => ({
      collection_name: String(row.collection_name),
      record_id: String(row.record_id),
      record_data: {},
      actor_id: row.actor_id || null,
      owner_id: row.owner_id || row.actor_id || null,
      updated_at: now,
      deleted_at: now,
    }));

  await upsertRawRows([...backupRows, ...tombstonesForExtraRows]);

  const afterRows = await fetchAllRemoteRows();
  const afterByKey = new Map(afterRows.map((row) => [remoteRowKey(row), row]));
  const mismatches = [];

  backupRows.forEach((expected) => {
    const actual = afterByKey.get(remoteRowKey(expected));
    if (!actual) {
      mismatches.push(remoteRowKey(expected));
      return;
    }

    if (
      Boolean(expected.deleted_at) !== Boolean(actual.deleted_at) ||
      stableJson(expected.record_data || {}) !== stableJson(actual.record_data || {})
    ) {
      mismatches.push(remoteRowKey(expected));
    }
  });

  const backupActiveKeys = new Set(
    backupRows.filter((row) => !row.deleted_at).map(remoteRowKey)
  );
  const unexpectedActiveRows = afterRows.filter(
    (row) => !row.deleted_at && !backupActiveKeys.has(remoteRowKey(row))
  );

  if (mismatches.length || unexpectedActiveRows.length) {
    throw new Error(
      `Supabase restore verification failed (${mismatches.length} mismatched, ${unexpectedActiveRows.length} unexpected active rows).`
    );
  }

  return {
    restoredRows: backupRows.length,
    archivedExtraRows: tombstonesForExtraRows.length,
    verified: true,
  };
}
