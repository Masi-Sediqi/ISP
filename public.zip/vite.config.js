import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  base: "./",
  cacheDir: "node_modules/.vite-isp-smart",
  plugins: [react()],
  server: {
    host: "0.0.0.0",
    port: 5173,
    strictPort: true,
    proxy: {
      "/api": {
        target: "http://127.0.0.1:5050",
        changeOrigin: true,
      },
      "/socket.io": {
        target: "http://127.0.0.1:5050",
        changeOrigin: true,
        ws: true,
      },
    },
  },
  build: {
    sourcemap: false
  }
});
